async function login() {
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    const response = await fetch('/login/', {
        method: 'GET',
        headers: {
            'Authorization': 'Basic ' + btoa(username + ':' + password)
        }
    });

    const loginStatus = document.getElementById("login-status");

    if (response.ok) {
        loginStatus.textContent = "Login successful";
    } else {
        loginStatus.textContent = "Login failed. Please check your username or password is correct.";
    }
}
