from fastapi import FastAPI, HTTPException, Depends, Cookie, Response, status
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from passlib.context import CryptContext
from databases import Database
import sqlite3

app = FastAPI()
security = HTTPBasic()
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
database = Database("sqlite:///users.db")

# Function to create a user table in the SQLite database
async def create_table():
    query = """CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY,
                    username TEXT UNIQUE NOT NULL,
                    password TEXT NOT NULL
                );"""
    await database.execute(query)


# Function to insert a new user into the SQLite database
async def create_user(username: str, password: str):
    query = "INSERT INTO users (username, password) VALUES (:username, :password);"
    hashed_password = pwd_context.hash(password)
    await database.execute(query, values={"username": username, "password": hashed_password})


# Function to get a user from the SQLite database by username
async def get_user(username: str):
    query = "SELECT * FROM users WHERE username = :username;"
    return await database.fetch_one(query, values={"username": username})


# Dependency to check if a user is authenticated
async def is_authenticated(credentials: HTTPBasicCredentials = Depends(security)):
    user = await get_user(credentials.username)
    if user is None or not pwd_context.verify(credentials.password, user["password"]):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials",
            headers={"WWW-Authenticate": "Basic"},
        )
    return user


@app.on_event("startup")
async def startup():
    await database.connect()
    await create_table()
    # Create some example users for testing
    await create_user("john_doe", "password123")
    await create_user("jane_smith", "qwerty987")


@app.on_event("shutdown")
async def shutdown():
    await database.disconnect()


@app.get("/login/")
async def login(response: Response, user: dict = Depends(is_authenticated)):
    # Set a cookie to remember the authenticated user
    response.set_cookie(key="user_id", value=str(user["id"]), httponly=True)
    return {"message": "Login successful"}

